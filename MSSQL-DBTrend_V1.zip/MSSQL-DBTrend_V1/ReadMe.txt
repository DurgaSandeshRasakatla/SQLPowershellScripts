<###########################################################################
# 																	
# Author       : DurgaSandesh R									
# Date         : 10th September 2020									
# Version      : 1.0												
# Desctiption  : This utility will help to retrieve SQL Server Database growth, comparing 12months Backup history.
# DataBase trend- How to use
#
# 1)	Enter the required server IP/hostnames in ServerList.txt
# 2)	Go to .\DBTrend_V1.ps1 PS available directory 
# 3)	Run �.\DBTrend_V1.ps1 | ConvertTo-Html -Property DatabaseName,YearMonth,MinSizeMB,MaxSizeMB,AvgSizeMB,GrowthMB -Head $Header | Out-File -FilePath Output.html�
#																	
###########################################################################>


