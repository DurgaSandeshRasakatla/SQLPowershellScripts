﻿<###########################################################################
# 																	
# Author       : DurgaSandesh R									
# Date         : 10th September 2020									
# Version      : 1.0												
# Desctiption  : This utility will help to retrieve SQL Server Database growth, comparing 12months Backup history.
# DataBase trend- How to use
#
# 1)	Enter the required server IP/hostnames in ServerList.txt
# 2)	Go to .\DBTrend_V1.ps1 PS available directory 
# 3)	Run “.\DBTrend_V1.ps1 | ConvertTo-Html -Property DatabaseName,YearMonth,MinSizeMB,MaxSizeMB,AvgSizeMB,GrowthMB -Head $Header | Out-File -FilePath Output-UAT.html”
#																	
###########################################################################>






$Command = "DECLARE @endDate datetime, @months smallint; 
SET @endDate = GetDate();  -- Include in the statistic all backups from today 
SET @months = 12;           -- back to the last 12 months. 
select @@SERVERNAME
;WITH HIST AS 
   (SELECT BS.database_name AS DatabaseName 
          ,YEAR(BS.backup_start_date) * 100 
           + MONTH(BS.backup_start_date) AS YearMonth 
          ,CONVERT(numeric(10, 1), MIN(BF.file_size / 1048576.0)) AS MinSizeMB 
          ,CONVERT(numeric(10, 1), MAX(BF.file_size / 1048576.0)) AS MaxSizeMB 
          ,CONVERT(numeric(10, 1), AVG(BF.file_size / 1048576.0)) AS AvgSizeMB 
    FROM msdb.dbo.backupset as BS 
         INNER JOIN 
         msdb.dbo.backupfile AS BF 
             ON BS.backup_set_id = BF.backup_set_id 
    WHERE NOT BS.database_name IN 
              ('master', 'msdb', 'model', 'tempdb') 
          AND BF.file_type = 'D' 
          AND BS.backup_start_date BETWEEN DATEADD(mm, - @months, @endDate) AND @endDate 
    GROUP BY BS.database_name 
            ,YEAR(BS.backup_start_date) 
            ,MONTH(BS.backup_start_date)) 
SELECT 
        MAIN.DatabaseName 
      ,MAIN.YearMonth 
      ,MAIN.MinSizeMB 
      ,MAIN.MaxSizeMB 
      ,MAIN.AvgSizeMB 
      ,MAIN.AvgSizeMB  
       - (SELECT TOP 1 SUB.AvgSizeMB 
          FROM HIST AS SUB 
          WHERE SUB.DatabaseName = MAIN.DatabaseName 
                AND SUB.YearMonth < MAIN.YearMonth 
          ORDER BY SUB.YearMonth DESC) AS GrowthMB 
FROM HIST AS MAIN 
ORDER BY MAIN.DatabaseName 
        ,MAIN.YearMonth"




$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@

foreach ($svr in get-content "C:\Users\dbadmin\Downloads\MSSQL-DBTrend\Serverlist.txt")
{
Invoke-Sqlcmd -ServerInstance $svr -Query $Command 
}

